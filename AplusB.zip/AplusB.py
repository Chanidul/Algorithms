
x = int(input())
y = int(input())
z = x + y
print(z)



